var text = "Hello, World!";
text