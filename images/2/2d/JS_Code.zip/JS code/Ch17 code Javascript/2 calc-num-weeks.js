var days = 77;
var weeks;

weeks = days/7;

weeks