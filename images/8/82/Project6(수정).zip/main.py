from app import *

def on_closing():
    global interrupt
    if messagebox.askokcancel("종료", "종료하시겠습니까?"):
        root.destroy()
        interrupt = 0

if __name__ == "__main__":
    global interrupt
    interrupt = 1
    width = 4
    root = Tk()

    while True:
        app = App(root, width)
        root.protocol("WM_DELETE_WINDOW", on_closing)
        root.mainloop()
        if app.continue_game == 'no' or interrupt == 0:
            break
