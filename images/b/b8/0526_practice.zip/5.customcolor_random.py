from tkinter import *
import random

def rgbString(red, green, blue):
    return "#%02x%02x%02x" % (red, green, blue)

def draw(canvas, width, height):
    n = 6
    margin = 5
    #colors = [rgbString(77,137,99),rgbString(105,165,131),rgbString(225,179,120),rgbString(224,204,151),rgbString(236,121,154),rgbString(159,2,81)]
    (rectWidth, rectHeight) = (width/n, height)
    for i in range(n):
        (x,y) = (i*rectWidth, 0)        
        canvas.create_rectangle(x+margin,y+margin, x+rectWidth, y+height-margin, fill=rgbString(random.randint(0,256),random.randint(0,256),random.randint(0,256)))
        
width = 400
height = 400
root = Tk()
canv = Canvas(root, width=width, height=height)
draw(canv, 400, 200)
canv.pack()
root.mainloop()
