from tkinter import *

def rgbString(red, green, blue):
    return "#%02x%02x%02x" % (red, green, blue)

def drawTree(canvas, x0, y0, x1, y1):
    width = x1-x0
    height = y1-y0

    canvas.create_oval(x0+width/8, y0+10, x0+width*7/8, y0+10+height/2, fill='green2', outline='green2')
    canvas.create_polygon((x0+width*7/16, y0+height/2), (x0+width/4, y0+height/4), (x0+width*7/16, y0+height/3), (x0+width/2, y0+height/8), (x0+width*9/16, y0+height/3), (x0+width*3/4, y0+height/4), (x0+width*9/16, y0+height/2), (x0+width*9/16,y0+height), (x0+width*7/16,y0+height),fill='brown',outline='brown')
    canvas.create_text(x0+width/2, y0+height*6/8, text='TREE', fill='white', font='Helvetica 12 bold')

def drawHouse(canvas, x0, y0, x1, y1):
    width = x1- x0
    height = y1 - y0

    canvas.create_rectangle(x0+width/8, y0+height/2, x0+width*7/8, y0+height, fill=rgbString(128,0,0))
    canvas.create_polygon((x0+width,y0+height/2),(x0,y0+height/2), (x0+width/8, y0+height/6), (x0+width*7/8, y0+height/6), fill=rgbString(0,64,128))
    canvas.create_rectangle(x0+width*10/16, y0+height/12, x0+width*12/16, y0+height/6, fill='brown', outline='brown')
    canvas.create_rectangle(x0+width*19/32, y0+height/24, x0+width*25/32, y0+height/12, fill='brown', outline='brown')
    canvas.create_rectangle(x0+width*9/16, y0+height*7/12, x0+width*12/16, y0+height*9/12, fill='black')
    canvas.create_rectangle(x0+width*4/16, y0+height*7/12, x0+width*7/16, y0+height*9/12, fill='black')
    canvas.create_text(x0+width*4/8, y0+height*11/12, text="HOUSE", fill='white', font='Helvetica 26 bold')

width = 400
height = 400
root = Tk()
canv = Canvas(root, width=width, height=height)
#drawHouse(canv,0,0,400,400)
drawTree(canv, 0, 0, 400, 400)
canv.pack()
root.mainloop()
