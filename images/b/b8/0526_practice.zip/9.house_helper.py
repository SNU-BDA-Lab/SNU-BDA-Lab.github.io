from tkinter import *
import random

def rgbString(red, green, blue):
    return "#%02x%02x%02x" % (red, green, blue)

def drawHouse(canvas, x0, y0, x1, y1):
    width = x1- x0
    height = y1 - y0

    canvas.create_rectangle(x0+width/8, y0+height/2, x0+width*7/8, y0+height, fill=rgbString(128,0,0))
    canvas.create_polygon((x0+width,y0+height/2),(x0,y0+height/2), (x0+width/8, y0+height/6), (x0+width*7/8, y0+height/6), fill=rgbString(0,64,128))
    canvas.create_rectangle(x0+width*10/16, y0+height/12, x0+width*12/16, y0+height/6, fill='brown', outline='brown')
    canvas.create_rectangle(x0+width*19/32, y0+height/24, x0+width*25/32, y0+height/12, fill='brown', outline='brown')
    canvas.create_rectangle(x0+width*9/16, y0+height*7/12, x0+width*12/16, y0+height*9/12, fill='black')
    canvas.create_rectangle(x0+width*4/16, y0+height*7/12, x0+width*7/16, y0+height*9/12, fill='black')
    #canvas.create_text(x0+width*4/8, y0+height*11/12, text="HOUSE", fill='white', font='Helvetica')

def drawTree(canvas, x0, y0, x1, y1):
    width = x1-x0
    height = y1-y0

    canvas.create_oval(x0+width/8, y0, x0+width*7/8, y0+height/2, fill='green2', outline='green2')
    canvas.create_polygon((x0+width*7/16, y0+height/2), (x0+width/4, y0+height/4), (x0+width*7/16, y0+height/3), (x0+width/2, y0+height/8), (x0+width*9/16, y0+height/3), (x0+width*3/4, y0+height/4), (x0+width*9/16, y0+height/2), (x0+width*9/16,y0+height), (x0+width*7/16,y0+height),fill='brown',outline='brown')
    #canvas.create_text(x0+width/2, y0+height*6/8, text='TREE', fill='white')

def drawBelgianFlag(canvas, x0, y0, x1, y1):
    width = (x1-x0)
    canvas.create_rectangle(x0,y0,x0+width/3,y1,fill="black",width=0)
    canvas.create_rectangle(x0+width/3, y0, x0+width*2/3, y1, fill='yellow', width=0)
    canvas.create_rectangle(x0+width*2/3, y0, x1, y1, fill='red', width=0)



def drawVillage(canvas, width, height):
    houseWidth = 50
    houseHeight = 50
    margin = 5

    for row in range(4):
        for col in range(6):
            left = 50 + col * houseWidth + margin
            top = 50 + row * houseHeight + margin
            right = left + houseWidth - margin
            bottom = top + houseHeight - margin            
            if random.random() > 0.5:
                drawHouse(canvas,left,top,right,bottom)
            else:
                drawTree(canvas,left,top,right,bottom)
            
width = 400
height = 400
root = Tk()
canv = Canvas(root, width = width, height = height)
canv.pack()
#drawHouse(canv, 200,200,300,300)
drawVillage(canv,400,400)
