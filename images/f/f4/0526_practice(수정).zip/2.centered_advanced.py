from tkinter import *

def draw(canvas, width, height):
    n = 5
    margin = 10
    colors = ['red', 'orange', 'yellow', 'green2', 'blue2']
    
    (cx, cy) = (width/2, height/2)
    for i in range(n,0,-1):
        (rectWidth, rectHeight) = (i*width/2/n, i*height/2/n)
        
        canvas.create_rectangle(cx - rectWidth+margin, cy-rectHeight+margin, cx+rectWidth-margin, cy+rectHeight-margin, fill=colors[i-1])
        
width = 400
height = 400
root = Tk()
canv = Canvas(root, width=width, height=height)
draw(canv, 400, 200)
canv.pack()
root.mainloop()
